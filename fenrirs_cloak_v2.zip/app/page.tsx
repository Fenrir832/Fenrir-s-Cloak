import { Header } from '../components/Header';
import { Footer } from '../components/Footer';
import { ProductGrid } from '../components/ProductGrid';
import { NewsletterForm } from '../components/NewsletterForm';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-white text-black">
      <Header />
      <section className="text-center py-20 bg-gray-100">
        <h2 className="text-4xl font-bold mb-4">Elevate Your Streetwear</h2>
        <p className="text-lg text-gray-700 mb-6">Unleash the wolf within – wear Fenrir's Cloak</p>
        <button className="bg-black text-white px-4 py-2 rounded">Shop Now</button>
      </section>
      <ProductGrid />
      <NewsletterForm />
      <Footer />
    </main>
  );
}