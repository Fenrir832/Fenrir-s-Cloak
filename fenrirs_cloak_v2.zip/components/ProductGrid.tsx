const products = [
  { id: 1, name: "Classic Tee", price: "$39.99" },
  { id: 2, name: "Wolf Print Tee", price: "$42.99" },
  { id: 3, name: "Urban Grey Tee", price: "$44.99" }
];

export function ProductGrid() {
  return (
    <section id="shop" className="p-8">
      <h3 className="text-3xl font-semibold mb-6">Our Products</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <div key={product.id} className="border p-4 rounded shadow hover:shadow-lg">
            <img src="/placeholder.jpg" alt="T-shirt" className="mb-4 rounded" />
            <h4 className="font-bold text-lg">{product.name}</h4>
            <p className="text-sm text-gray-600">{product.price}</p>
            <button className="mt-4 w-full bg-black text-white py-2 rounded">Add to Cart</button>
          </div>
        ))}
      </div>
    </section>
  );
}