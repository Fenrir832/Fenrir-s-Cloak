export function Header() {
  return (
    <header className="flex justify-between items-center p-6 shadow-md">
      <h1 className="text-2xl font-bold">Fenrir's Cloak</h1>
      <nav className="space-x-4">
        <a href="/" className="hover:underline">Home</a>
        <a href="#shop" className="hover:underline">Shop</a>
        <a href="#cart" className="hover:underline">Cart</a>
      </nav>
    </header>
  );
}