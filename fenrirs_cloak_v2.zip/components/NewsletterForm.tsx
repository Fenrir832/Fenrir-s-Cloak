export function NewsletterForm() {
  return (
    <section className="bg-black text-white p-8 text-center">
      <h4 className="text-2xl font-semibold mb-4">Join the Pack</h4>
      <p className="mb-4">Subscribe for updates, drops, and exclusive deals.</p>
      <input type="email" placeholder="Enter your email" className="p-2 rounded text-black mr-2" />
      <button className="bg-white text-black px-4 py-2 rounded">Subscribe</button>
    </section>
  );
}